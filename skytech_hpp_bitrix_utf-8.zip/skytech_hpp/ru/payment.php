<?
global $MESS;

$MESS["SPCP_DTITLE"] = "Skytech";
$MESS["SPCP_DDESCR"] = "<a href=\"http://skytecrussia.com\" target=\"_blank\">http://skytecrussia.com</a>";
$MESS["MERCHANT_ID"] = "Идентификатор магазина (merchant id)";
$MESS["MERCHANT_ID_DESCR"] = "Код магазина полученный от Skytech";
$MESS["MERCHANT_ID_DESCT"] = "";
$MESS["ORDER_ID"] = "Номер заказа";
$MESS["ORDER_ID_DESCR"] = "";
$MESS["SECRET_KEY"] = "Секретный ключ";
$MESS["SECRET_KEY_DESCR"] = "Секретный ключ полученный от Skytech";
$MESS["SHOULD_PAY"] = "Сумма заказа";
$MESS["SHOULD_PAY_DESCR"] = "Сумма к оплате";
$MESS["ORDER_DATE"] = "Дата создания заказа";
$MESS["ORDER_DATE_DESCR"] = "";
$MESS["IS_TEST"] = "Тестовый режим";
$MESS["IS_TEST_DESCR"] = "Если пустое значение - магазин будет работать в обычном режиме";
$MESS["PYM_CHANGE_STATUS_PAY"] = "Автоматически оплачивать заказ при получении успешного статуса оплаты";
$MESS["PYM_CHANGE_STATUS_PAY_DESC"] = "Y - оплачивать, N - не оплачивать.";
?>
