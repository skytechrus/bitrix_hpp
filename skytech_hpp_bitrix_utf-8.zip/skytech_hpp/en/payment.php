<?
global $MESS;

$MESS["SPCP_DTITLE"] = "Skytech";
$MESS["SPCP_DDESCR"] = "<a href=\"http://skytecrussia.com\" target=\"_blank\">http://skytecrussia.com</a>";
$MESS["MERCHANT_ID"] = "Merchant ID";
$MESS["SECRET_KEY"] = "Secret key";
$MESS["SECRET_KEY_DESCR"] = "";
$MESS["ORDER_ID"] = "Order ID";
$MESS["SHOULD_PAY"] = "Order amount";
$MESS["ORDER_DATE"] = "Order date";
$MESS["IS_TEST"] = "Test mode";
$MESS["IS_TEST_DESCR"] = "If empty - shop will work in normal mode";
?>